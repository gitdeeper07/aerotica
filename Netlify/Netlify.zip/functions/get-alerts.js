const { createClient } = require('@supabase/supabase-js');

exports.handler = async (event) => {
  const headers = {
    'Access-Control-Allow-Origin': '*',
    'Content-Type': 'application/json'
  };

  try {
    const supabase = createClient(
      process.env.SUPABASE_URL,
      process.env.SUPABASE_SERVICE_KEY
    );

    const { status = 'all' } = event.queryStringParameters || {};
    
    let query = supabase.from('alerts').select('*');
    if (status !== 'all') {
      query = query.eq('status', status);
    }
    
    const { data: alerts, error } = await query;
    if (error) throw error;

    return {
      statusCode: 200,
      headers,
      body: JSON.stringify({
        total: alerts.length,
        active: alerts.filter(a => a.status === 'active').length,
        alerts: alerts
      })
    };
  } catch (error) {
    return {
      statusCode: 500,
      headers,
      body: JSON.stringify({ error: error.message })
    };
  }
};
