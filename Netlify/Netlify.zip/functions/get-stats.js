const { createClient } = require('@supabase/supabase-js');

exports.handler = async () => {
  const headers = {
    'Access-Control-Allow-Origin': '*',
    'Content-Type': 'application/json'
  };

  try {
    const supabase = createClient(
      process.env.SUPABASE_URL,
      process.env.SUPABASE_SERVICE_KEY
    );

    const { data: sites } = await supabase.from('sites').select('*');
    const { data: alerts } = await supabase.from('alerts').select('*').eq('status', 'active');

    return {
      statusCode: 200,
      headers,
      body: JSON.stringify({
        status: 'operational',
        version: '1.0.0',
        project: 'AEROTICA',
        metrics: {
          total_sites: sites.length,
          alerts: alerts.length
        },
        timestamp: new Date().toISOString()
      })
    };
  } catch (error) {
    return {
      statusCode: 500,
      headers,
      body: JSON.stringify({ error: error.message })
    };
  }
};
