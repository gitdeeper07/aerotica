const { createClient } = require('@supabase/supabase-js');

exports.handler = async () => {
  const headers = {
    'Access-Control-Allow-Origin': '*',
    'Content-Type': 'application/json'
  };

  try {
    const supabase = createClient(
      process.env.SUPABASE_URL,
      process.env.SUPABASE_SERVICE_KEY
    );

    const { data: sites, error } = await supabase.from('sites').select('*');
    
    if (error) throw error;

    // إضافة قيم AKE تقديرية بناءً على climate_zone
    const sitesWithAKE = sites.map(site => {
      let ake = 0.60; // قيمة افتراضية
      
      // تقدير حسب climate_zone
      switch(site.climate_zone) {
        case 'temperate': ake = 0.65; break;
        case 'arid': ake = 0.58; break;
        case 'tropical': ake = 0.55; break;
        case 'polar': ake = 0.52; break;
        case 'high_altitude': ake = 0.62; break;
      }
      
      // تعديل حسب site_type
      if (site.site_type === 'offshore') ake += 0.08;
      if (site.site_type === 'coastal') ake += 0.03;
      if (site.site_type === 'mountain') ake -= 0.02;
      
      return {
        ...site,
        ake: Number(ake.toFixed(3)),
        ake_score: Number(ake.toFixed(3))
      };
    });

    return {
      statusCode: 200,
      headers,
      body: JSON.stringify(sitesWithAKE)
    };
  } catch (error) {
    return {
      statusCode: 500,
      headers,
      body: JSON.stringify({ error: error.message })
    };
  }
};
