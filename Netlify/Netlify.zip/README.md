# 🌪️ AEROTICA Netlify Dashboard

## 🌐 Live Site
**Main Website**: https://aerotica-science.netlify.app

## 📊 Dashboard Sections
- **Home**: https://aerotica-science.netlify.app
- **Dashboard**: https://aerotica-science.netlify.app/dashboard
- **AKE Map**: https://aerotica-science.netlify.app/map
- **Gust Alerts**: https://aerotica-science.netlify.app/alerts
- **Documentation**: https://aerotica-science.netlify.app/documentation
- **Parameters**: https://aerotica-science.netlify.app/parameters
- **Case Studies**: https://aerotica-science.netlify.app/case-studies
- **Reports**: https://aerotica-science.netlify.app/reports

## 🔗 Quick Links (from research paper)
- 📄 Paper: https://doi.org/10.14293/AEROTICA.2026.001
- 🦊 GitLab: https://gitlab.com/gitdeeper07/aerotica
- 🐙 GitHub: https://github.com/gitdeeper07/aerotica
- 📦 PyPI: https://pypi.org/project/aerotica-ake
- 🤗 Hugging Face: https://huggingface.co/spaces/gitdeeper07/aerotica
- 🔬 Zenodo: https://doi.org/10.5281/zenodo.aerotica2026
- 📊 Dashboard: https://aerotica-science.netlify.app

## 📁 Structure

```

netlify/
├── public/           # Static files (HTML, CSS, JS, images)
├── functions/        # Serverless functions for API endpoints
│   ├── compute-ake.js
│   ├── compute-ked.js
│   ├── compute-thd.js
│   ├── compute-vsr.js
│   ├── get-alerts.js
│   ├── get-parameters.js
│   ├── list-sites.js
│   └── run-validation.js
├── config/           # Configuration files
├── .env.example      # Environment variables template
├── netlify.toml      # Netlify configuration
└── README.md         # This file

```

## 🚀 Deployment

### Automatic Deployment
The site automatically deploys when changes are pushed to the `main` branch:
- `git push origin main`

### Manual Deployment
```bash
# Install Netlify CLI
npm install -g netlify-cli

# Deploy to production
netlify deploy --prod --dir=public
```

🔧 Local Development

```bash
# Clone the repository
git clone https://github.com/gitdeeper07/aerotica.git
cd aerotica/netlify

# Install dependencies
npm install

# Run locally
netlify dev
```

📧 Contact

Samir Baladi - gitdeeper@gmail.com
ORCID: 0009-0003-8903-0029

📄 License

MIT License

🏷️ Version

1.0.0 - February 2026
