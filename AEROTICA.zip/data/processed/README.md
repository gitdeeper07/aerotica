# Processed Data Directory

This directory contains processed data including:
- AKE scores
- PINN inference outputs
- Pre-alert logs
- Validation results
- Assessment reports

Data formats: CSV, NetCDF, JSON, GeoJSON
