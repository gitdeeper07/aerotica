# Raw Data Directory

This directory contains raw observational data including:
- Surface meteorological station data
- Radiosonde profiles
- Doppler radar data
- LiDAR surveys
- Satellite observations

Data formats: CSV, NetCDF, GRIB, HDF, GeoTIFF
