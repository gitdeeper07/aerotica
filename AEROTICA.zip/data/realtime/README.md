# Real-time Data Directory

This directory contains real-time observational data:
- Current surface observations
- Latest radar scans
- Real-time satellite data
- Streaming sensor data

Data formats: CSV, JSON, NetCDF
