# LES Benchmarks Directory

This directory contains Large Eddy Simulation benchmark data:
- 1,247 high-fidelity LES simulations
- OpenFOAM 10 outputs
- Validation reference data
- Comparison metrics

Data formats: HDF5, NetCDF
