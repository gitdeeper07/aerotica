"""Integration tests for AEROTICA."""
