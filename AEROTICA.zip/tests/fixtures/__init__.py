"""Test fixtures for AEROTICA."""
