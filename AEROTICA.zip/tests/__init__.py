"""AEROTICA test suite."""
