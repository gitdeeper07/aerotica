
Benchmark Results

This directory contains benchmark results:

· performance/ - Speed benchmarks
· accuracy/ - Accuracy benchmarks
· comparison/ - Model comparisons
· baseline.json - Baseline metrics
