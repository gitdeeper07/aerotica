# Jupyter Notebooks

This directory contains Jupyter notebooks for:
- Data exploration
- Visualization
- Analysis examples
- Tutorials

To run notebooks:
```bash
jupyter notebook
```

