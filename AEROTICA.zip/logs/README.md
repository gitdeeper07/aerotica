
System Logs

This directory contains system logs:

· aerotica.log - Main application log
· alerts.log - Gust alert log
· errors.log - Error log
· performance.log - Performance metrics
