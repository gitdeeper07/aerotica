# API Documentation

This directory contains API documentation:
- `reference.md` - API reference
- `endpoints.md` - Endpoint descriptions
- `examples.md` - Usage examples
