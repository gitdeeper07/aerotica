# Examples Documentation

This directory contains example documentation:
- `urban_assessment.md` - Urban wind examples
- `offshore_optimization.md` - Offshore examples
- `gust_alert.md` - Gust alert examples
