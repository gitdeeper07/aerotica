# PINN Model Weights

This directory contains pre-trained Physics-Informed Neural Network weights:
- `velocity_net_[zone].pt` - Velocity network weights
- `pressure_net_[zone].pt` - Pressure network weights  
- `temperature_net_[zone].pt` - Temperature network weights

Climate zones: tropical, arid, temperate, continental, polar, high_altitude

Total size: ~4 GB
