# Bayesian Weights

This directory contains Bayesian-optimized weights:
- `posterior_samples.rds` - MCMC posterior samples
- `weight_distributions.json` - Weight statistics
- `credible_intervals.json` - 95% credible intervals
