# AKE Thresholds

This directory contains classification thresholds:
- `global_thresholds.json` - Global thresholds
- `climate_zone_thresholds.json` - Zone-specific thresholds
- `application_thresholds.json` - Application-specific thresholds
